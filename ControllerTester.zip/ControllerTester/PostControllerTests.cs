using Xunit;
using UDiscuss.Controllers;
using UDiscuss.Models;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;
using System;
using static UDiscuss.Controllers.PostController;
using System.Collections.Generic;

namespace ControllerTester
{
    public class PostControllerTests
    {

        /// <summary>
        /// Creates a local mock data base with the given name.
        /// </summary>
        /// <param name="mockName">The name of the database.</param>
        /// <returns>The new mock database with the matching name.</returns>
        private mainContext createMockWithName(string mockName)
        {
            var optionsbuilder = new DbContextOptionsBuilder<mainContext>();

            optionsbuilder.UseInMemoryDatabase(mockName);

            mainContext mock = new mainContext(optionsbuilder.Options);

            return mock;
        }

        private bool equalPostDTO(PostDTO p1, PostDTO p2)
        {
            return p1.title == p2.title &&
                p1.category == p2.category &&
                p1.dateCreated == p2.dateCreated &&
                p1.body == p2.body &&
                p1.authorFName == p2.authorFName &&
                p1.authorLName == p2.authorLName &&
                p1.relativeID == p2.relativeID;
        }

        /// <summary>
        /// Creates a databases with a class with an id of 1, category with id 2, and
        /// post id 1. 
        /// </summary>
        /// <returns>The database with one post, class, postcategory, and user.</returns>
        private mainContext singlePostDB()
        {
            mainContext mock = createMockWithName("SinglePost");

            User user = new()
            {
                UserId = (uint)1234567,
                FirstName = "Mark",
                LastName = "Pat",
                Email = "test@utah.edu",
                IsAdmin = false
            };

            mock.Users.Add(user);
            mock.SaveChanges();

            Class c = new()
            {
                ClassId = 1,
                FullName = "CS 5530 Database",
                ShortName = "CS5530",
                Semester = "Summer",
                Year = 2022
            };

            mock.Classes.Add(c);
            mock.SaveChanges();

            PostCategory category = new()
            {
                CategoryId = 2,
                Name = "category name",
                ClassId = 1
            };

            mock.PostCategories.Add(category);
            mock.SaveChanges();

            Post newPost = new()
            {
                PostId = 1,
                ClassId = 1,
                CategoryId = 2,
                Category = category,
                AuthorId = (uint)1234567,
                Title = "This is a title",
                Body = "What is this text? It is the body of the post!",
                RelativeId = 1,
                DateCreated = new DateTime(2022, 10, 10)
            };

            mock.Posts.Add(newPost);
            mock.SaveChanges();

            return mock;
        }

        private mainContext singlePostDBContent()
        {
            mainContext mock = createMockWithName("SingleContext");

            User user = new()
            {
                UserId = (uint)1234567,
                FirstName = "Mark",
                LastName = "Pat",
                Email = "test@utah.edu",
                IsAdmin = false
            };

            mock.Users.Add(user);
            mock.SaveChanges();

            Class c = new()
            {
                ClassId = 1,
                FullName = "CS 5530 Database",
                ShortName = "CS5530",
                Semester = "Summer",
                Year = 2022
            };

            mock.Classes.Add(c);
            mock.SaveChanges();

            PostCategory category = new()
            {
                CategoryId = 2,
                Name = "category name",
                ClassId = 1
            };

            mock.PostCategories.Add(category);
            mock.SaveChanges();

            Post newPost = new()
            {
                PostId = 1,
                ClassId = 1,
                CategoryId = 2,
                Category = category,
                AuthorId = (uint)1234567,
                Title = "This is a title",
                Body = "What is this text? It is the body of the post!",
                RelativeId = 1,
                DateCreated = new DateTime(2022, 10, 10)
            };

            mock.Posts.Add(newPost);
            mock.SaveChanges();

            return mock;
        }

        [Fact]
        public void GetByIdSingleItem()
        {
            PostController controller = new PostController();

            controller.UseContext(singlePostDB());

            List<PostDTO> result = (List<PostDTO>) controller.Get(1);

            Assert.Single(result);
        }

        [Fact]
        public void GetContentsOfPostSingleItem()
        {
            PostController controller = new PostController();

            controller.UseContext(singlePostDBContent());

            List<PostDTO> result = (List<PostDTO>)controller.Get(1);

            PostDTO expectedPost = new()
            {
               title = "This is a title",
               category = "category name",
               dateCreated = new DateTime(2022, 10, 10),
               body = "What is this text? It is the body of the post!",
               authorFName = "Mark",
               authorLName = "Pat",
               relativeID = 1
            };

            PostDTO resultPost = result[0];

            Assert.True(equalPostDTO(expectedPost, resultPost));
        }
    }
}